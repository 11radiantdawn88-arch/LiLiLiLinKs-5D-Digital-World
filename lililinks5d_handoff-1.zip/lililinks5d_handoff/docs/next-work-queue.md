# Ordered implementation queue

This is the working queue; mark an item complete only after its acceptance test passes.

- [ ] HoloMeet: implement authenticated signaling adapter and room membership RLS.
- [ ] HoloMeet: perfect negotiation/glare handling, ICE restart, replaceTrack camera switching, reconnect and call timeout.
- [ ] HoloMeet: configure TURN provider and test two Android devices on different carrier networks.
- [ ] HoloMeet: integrate camera stage into existing route and remove obsolete dimensional labels that conflict with 5D product language.
- [ ] Shared: inventory current routes, components, tables, RLS policies and edge functions before schema changes.
- [ ] Shared: notifications, moderation, blocking/reporting, audit and account privacy flows.
- [ ] LiLiMaps: provider selection, attribution, map/search/routing and location-permission UX.
- [ ] LiLiBuzz: schema, feed, post/media upload, follows, comments, reactions and moderation.
- [ ] LiLiWatch: storage/transcoding provider, channels, video metadata, playback, captions, creator tools.
- [ ] LiLiGlow: search/browser shell, safe navigation and external-site boundaries.
- [ ] LiLiMail: domain ownership, DNS authentication and transactional email provider.
- [ ] LiLiAds: consent, inventory, measurement, policy and authorized Google account connection.
- [ ] LiLiStore: audit existing Stripe configuration; server-side checkout, verified webhooks, refunds and idempotency.
- [ ] LiLiGames: free-to-play first; keep wagering/payout disabled pending legal/licensing/security approvals.
- [ ] Android, accessibility, security, load and regression QA across modules.
- [ ] Production deployment, live smoke tests, monitoring and rollback plan.
- [ ] Reconcile publishing status registry with metadata and verify canonical production URL with a live smoke test.
- [ ] Expand navigation/module registry from the five existing modules to the complete requested LiLiLinKs module set without breaking current routes.
