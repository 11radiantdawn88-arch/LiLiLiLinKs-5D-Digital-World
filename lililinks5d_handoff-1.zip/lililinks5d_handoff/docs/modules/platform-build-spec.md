# LiLiLinKs 5D — connected platform build specification

## Product contract
LiLiLinKs is one connected platform, not unrelated microsites. LiLiID is the shared identity and authorization layer. Each module owns its domain data but uses the same authenticated user, notification preferences, moderation rules, accessibility patterns, and audit conventions. Preserve the 5D experience language; do not relabel it as 3D.

## Shared foundation (must precede module launch)
- Authentication: retain existing Supabase Auth; no second login database.
- Profiles: extend existing `profiles` only through reviewed migrations; handle/identity uniqueness must be enforced server-side.
- Authorization: deny by default; verify ownership and role in database policies and server functions, not only in UI.
- Notifications: user-scoped inbox, read state, category preferences, delivery status, and opt-out controls.
- Media: private-by-default uploads, signed URLs, size/type limits, abuse reporting, retention and deletion workflows.
- Safety: block/report, moderation queue, rate limits, age-appropriate defaults, audit events, and account deletion/export process.
- Observability: structured error reporting, health checks, and no secrets or message bodies in logs.

## Module acceptance criteria

### LiLiID
One account across modules; profile, handle, avatar, privacy settings, sessions, connected devices, account recovery, export/delete requests, and role-aware access. Existing Supabase Auth remains authoritative.

### LiLiMeet
1:1 calling first; authenticated room membership; camera/microphone permission UX; local and remote tracks; front/rear camera switch; mute/camera-off; call states; hangup; reconnect; TURN; abuse reporting. Group calls and spatial scene composition follow only after 1:1 reliability. Life-size projection requires compatible display hardware; phone-only fallback is immersive full-screen video.

### LiLiMaps
MapLibre map surface; OpenStreetMap-compatible tiles; search/geocoding and routing provider selected explicitly; location permission only when needed; manual location fallback; saved places; business/event cards; report incorrect listings; attribution and provider usage limits visible.

### LiLiBuzz
Feed, follow graph, posts, comments, reactions, communities, creator profiles, notifications, block/report, moderation, pagination, upload pipeline, and privacy controls. Feed ranking must be explainable and allow chronological mode.

### LiLiWatch
Channels, video upload/transcoding pipeline, thumbnails, captions, playlists, subscriptions, likes/comments, short-form clips, live stream provider integration, creator analytics, copyright/report workflow, moderation, and storage/bandwidth cost controls. Do not stream large files through the app server.

### LiLiGlow
Search-first browser experience with safe external navigation, domain display, phishing warnings, popup/download controls, and clear distinction between search results and authenticated LiLiLinKs content. A web app cannot silently become a privileged system browser.

### LiLiMail
Inbox UI is not an email-delivery provider. Require verified `lilimail.com` DNS, sender authentication (SPF/DKIM/DMARC), provider credentials stored as secrets, bounce/complaint handling, suppression lists, and abuse monitoring before outbound email is enabled. Never expose mailbox credentials in frontend code.

### LiLiAds
Consent and privacy controls; placement inventory; campaign/creative review; impression/click measurement with fraud controls; frequency caps; reporting; policy compliance. Google Ads integration requires owner-authorized account connection and must follow Google's current policies. No ad tracking before required consent.

### LiLiStore and payments
Preserve existing catalog/cart. Stripe Checkout or Payment Element must be server-created; webhook signature verification is mandatory; idempotency keys and refunds/disputes required. Never trust client-reported payment success. Do not store card numbers.

### LiLiGames
Start with free-to-play games, matchmaking, leaderboards, chat safety, and anti-cheat. Real-money casino, poker wagering, keno, fish tables, deposits, and payouts are a separate regulated product requiring jurisdiction-by-jurisdiction legal review, licensing, age/identity verification, geolocation, AML controls, responsible-gaming controls, audited RNG, and approved payment providers. Keep wagering and payout disabled until every prerequisite is documented and approved.

## Release gates
A module is not “complete” until: migrations applied; RLS tested for anonymous/user/owner/admin; unit and integration tests pass; mobile Android Chrome tests pass; accessibility checks pass; secrets are server-side; error states and deletion flows work; provider costs/limits are documented; and production deployment is verified by opening the live URL and exercising the feature.
