# HoloMeet signaling adapter contract

`src/lib/holomeet/PeerCall.ts` implements the browser-side WebRTC negotiation state machine. It is not production-call-ready until a secure `SignalingTransport` is implemented and wired to authenticated room membership.

## Required adapter behavior
- Authenticate the user from the existing Supabase session.
- Subscribe only to signals in rooms where the user is an active participant.
- Validate sender and recipient membership on the server/database; never trust IDs supplied by a browser.
- Persist or relay offer/answer/ICE messages only to the intended peer.
- Apply short retention to signaling payloads and delete them after call completion.
- Rate-limit room creation, invitations, and signal volume.
- Never expose TURN credentials permanently in frontend source. Use short-lived TURN credentials from a server endpoint.
- Handle duplicate/out-of-order ICE messages, reconnects, tab closure, and call timeouts.

## ICE configuration
Development can use public STUN only for local testing. Production needs a managed TURN service or self-hosted TURN with TLS, authentication, monitoring, and regional capacity. STUN-only connectivity is not reliable across mobile carrier NATs and restrictive networks.

## Mobile acceptance tests
- Android Chrome HTTPS permission grant/deny/revoke.
- Switch front/rear camera during an active call using `RTCRtpSender.replaceTrack` (do not tear down the entire peer unnecessarily).
- Bluetooth headset route, speaker route, mute, background/foreground, screen lock, low bandwidth, Wi-Fi-to-cellular handoff.
- Permission denied, camera busy, no camera, remote hangup, network loss, TURN relay, and browser refresh.
- Explicit call end releases every MediaStream track and closes peer connections.

## Known implementation follow-ups
The starter `PeerCall` class covers basic offer/answer/ICE handling. Before shipping, add glare handling (perfect negotiation), ICE restart, reconnect policy, track replacement, device selection, and a fully tested Supabase or WebSocket adapter. The app must show a clear “connecting / reconnecting / failed” state rather than implying a call is live prematurely.
