import type { CallSignal, SignalingTransport, CallConfig } from "./types";

export type PeerCallState = "idle" | "connecting" | "connected" | "disconnected" | "failed" | "closed";

/**
 * One-to-one WebRTC peer. This class deliberately accepts a signaling adapter;
 * it does not pretend a browser can signal peers without a backend.
 */
export class PeerCall {
  private pc: RTCPeerConnection;
  private unsubscribe?: () => void;
  private pendingCandidates: RTCIceCandidateInit[] = [];
  private remoteDescriptionSet = false;
  private closed = false;

  constructor(
    private readonly roomId: string,
    private readonly localUserId: string,
    private readonly remoteUserId: string,
    private readonly transport: SignalingTransport,
    config: CallConfig,
    private readonly onRemoteStream: (stream: MediaStream) => void,
    private readonly onState: (state: PeerCallState) => void,
    private readonly onError: (error: Error) => void,
  ) {
    this.pc = new RTCPeerConnection({ iceServers: config.iceServers });
    this.pc.ontrack = (event) => {
      const stream = event.streams[0];
      if (stream) this.onRemoteStream(stream);
    };
    this.pc.onicecandidate = (event) => {
      if (!event.candidate || this.closed) return;
      void this.send("ice-candidate", event.candidate.toJSON()).catch(this.onError);
    };
    this.pc.onconnectionstatechange = () => {
      const state = this.pc.connectionState;
      if (state === "connected") this.onState("connected");
      else if (state === "connecting") this.onState("connecting");
      else if (state === "disconnected") this.onState("disconnected");
      else if (state === "failed") this.onState("failed");
      else if (state === "closed") this.onState("closed");
    };
  }

  async start(localStream: MediaStream, makeOffer: boolean): Promise<void> {
    if (this.closed) throw new Error("Call is already closed.");
    localStream.getTracks().forEach((track) => this.pc.addTrack(track, localStream));
    this.unsubscribe = this.transport.subscribe(
      this.roomId,
      this.localUserId,
      (signal) => void this.handleSignal(signal).catch(this.onError),
      this.onError,
    );
    if (makeOffer) {
      const offer = await this.pc.createOffer();
      await this.pc.setLocalDescription(offer);
      await this.send("offer", offer);
    }
  }

  private async handleSignal(signal: CallSignal): Promise<void> {
    if (this.closed || signal.senderId !== this.remoteUserId || signal.recipientId !== this.localUserId) return;
    if (signal.kind === "hangup") { this.close(false); return; }
    if (signal.kind === "offer" && signal.payload) {
      await this.pc.setRemoteDescription(signal.payload as RTCSessionDescriptionInit);
      this.remoteDescriptionSet = true;
      await this.flushCandidates();
      const answer = await this.pc.createAnswer();
      await this.pc.setLocalDescription(answer);
      await this.send("answer", answer);
    } else if (signal.kind === "answer" && signal.payload) {
      await this.pc.setRemoteDescription(signal.payload as RTCSessionDescriptionInit);
      this.remoteDescriptionSet = true;
      await this.flushCandidates();
    } else if (signal.kind === "ice-candidate" && signal.payload) {
      const candidate = signal.payload as RTCIceCandidateInit;
      if (!this.remoteDescriptionSet) this.pendingCandidates.push(candidate);
      else await this.pc.addIceCandidate(candidate);
    }
  }

  private async flushCandidates(): Promise<void> {
    const candidates = this.pendingCandidates.splice(0);
    for (const candidate of candidates) await this.pc.addIceCandidate(candidate);
  }

  private send(kind: CallSignal["kind"], payload: CallSignal["payload"]): Promise<void> {
    return this.transport.send({ roomId: this.roomId, senderId: this.localUserId, recipientId: this.remoteUserId, kind, payload });
  }

  async hangup(): Promise<void> {
    if (!this.closed) await this.send("hangup", null).catch(this.onError);
    this.close(false);
  }

  close(notify = false): void {
    if (this.closed) return;
    this.closed = true;
    if (notify) void this.send("hangup", null).catch(this.onError);
    this.unsubscribe?.();
    this.pc.ontrack = null;
    this.pc.onicecandidate = null;
    this.pc.close();
    this.onState("closed");
  }
}
