export type SignalKind = "offer" | "answer" | "ice-candidate" | "hangup";

export interface CallSignal {
  id: string;
  roomId: string;
  senderId: string;
  recipientId: string;
  kind: SignalKind;
  payload: RTCSessionDescriptionInit | RTCIceCandidateInit | null;
  createdAt: string;
}

/** Implement with Supabase Realtime or an authenticated WebSocket service. */
export interface SignalingTransport {
  send(signal: Omit<CallSignal, "id" | "createdAt">): Promise<void>;
  subscribe(
    roomId: string,
    currentUserId: string,
    onSignal: (signal: CallSignal) => void,
    onError: (error: Error) => void,
  ): () => void;
}

export interface CallConfig {
  iceServers: RTCIceServer[];
  /** TURN is strongly recommended for production calls across carrier/NAT networks. */
}
