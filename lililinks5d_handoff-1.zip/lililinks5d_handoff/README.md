# LiLiLinKs 5D — Offline implementation handoff

This package is a preparation workspace for the existing Lovable project `LiLiLinKs 5D World` (project ID `fc280985-2dab-4a80-a8ac-1f238ea64b4f`). It is not deployed and does not replace the existing project.

## Verified project baseline
- Existing app: TanStack Start + React + TypeScript + Supabase.
- Existing modules in navigation: LiLiID, LiLiStore, LiLiMail, HoloMeet, Games.
- Supabase/Lovable Cloud database is enabled.
- Existing HoloMeet page is a layout-only preview with empty seat markers; it does not capture camera/microphone or connect participants.
- Lovable currently reports the project needs attention because the workspace is out of credits.

## Important product truth
A phone camera cannot project a caller into the room. The app can capture both participants, composite/depth-process video, spatialize audio, and send a suitable output to a compatible projector/display. A life-size free-space hologram requires compatible display hardware. The Android-first experience must gracefully fall back to a full-screen immersive video call.

## Integration approach
Preserve the existing app, auth, profiles, products, carts, and database. Add features incrementally. Never create a second account system or overwrite the current app. Do not publish or charge users without owner authorization.

## Build order
1. HoloMeet real-time calling foundation and camera diagnostics.
2. LiLiMaps foundation (MapLibre + OpenStreetMap, search/geolocation permissions, route planning).
3. LiLiBuzz social feed and community model.
4. LiLiWatch creator/video platform foundation.
5. LiLiGlow web-search/browser shell with safe external navigation.
6. LiLiMail delivery integration after verified domain/provider setup.
7. LiLiAds consent-based ad inventory and reporting; connect Google Ads only after account authorization.
8. LiLiGames multiplayer and regulated-gaming compliance review. No real-money casino or payout flow is enabled by this package.
9. Shared LiLiID permissions, notifications, moderation, privacy, audit and admin tools.
10. Cross-module QA, Android QA, accessibility, security review, deployment checklist.

## Not included / external dependencies
- Real-time call signaling requires an authenticated signaling service and configured TURN/STUN for reliable calls across networks.
- LiLiMaps requires a selected tile/geocoding/routing service and its terms/limits to be respected.
- Email requires a verified sending domain and provider credentials.
- Google Ads requires an authorized Google Ads account and policy review.
- Real projector output requires compatible hardware and its documented interface.
- Payment processing requires the owner's verified Stripe setup.

## Expanded offline work added in this continuation
- `src/lib/holomeet/types.ts`: typed signaling contract for authenticated backend adapter.
- `src/lib/holomeet/PeerCall.ts`: browser WebRTC offer/answer/ICE peer foundation with cleanup and state reporting.
- `docs/holomeet-signaling-contract.md`: security, TURN, mobile QA, and remaining WebRTC hardening.
- `docs/modules/platform-build-spec.md`: connected architecture and module acceptance criteria for LiLiID, LiLiMeet, LiLiMaps, LiLiBuzz, LiLiWatch, LiLiGlow, LiLiMail, LiLiAds, LiLiStore, and LiLiGames.

These files are a development handoff, not yet merged into the Lovable repository. The signaling adapter, backend policies, production TURN credentials, media providers, DNS/email, ad account, payment webhooks, and device tests remain integration work.
