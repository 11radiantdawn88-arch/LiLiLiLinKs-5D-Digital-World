import type { SupabaseClient } from '@supabase/supabase-js';
import type {
  LiLiNotification,
  NotificationModule,
  NotificationPage,
  NotificationResult,
} from './types';

const TABLE = 'lili_notifications';
const PAGE_SIZE = 25;

function asError(value: unknown): Error {
  if (value instanceof Error) return value;
  if (typeof value === 'object' && value !== null && 'message' in value) {
    return new Error(String((value as { message: unknown }).message));
  }
  return new Error('The notification request failed.');
}

/**
 * Read notifications for the signed-in user. RLS remains the authority: this
 * helper never accepts a recipient ID from the caller.
 */
export async function listNotifications(
  client: SupabaseClient,
  options: { before?: string | null; unreadOnly?: boolean } = {},
): Promise<NotificationResult<NotificationPage>> {
  const { data: auth, error: authError } = await client.auth.getUser();
  if (authError || !auth.user) return { data: null, error: asError(authError ?? 'Sign in required.') };

  let query = client
    .from(TABLE)
    .select('id,recipient_id,actor_id,module,event_type,title,body,href,read_at,created_at', { count: 'exact' })
    .order('created_at', { ascending: false })
    .limit(PAGE_SIZE + 1);

  if (options.unreadOnly) query = query.is('read_at', null);
  if (options.before) query = query.lt('created_at', options.before);

  const { data, error, count } = await query;
  if (error) return { data: null, error: asError(error) };

  const rows = (data ?? []) as LiLiNotification[];
  const hasMore = rows.length > PAGE_SIZE;
  const items = rows.slice(0, PAGE_SIZE);
  const { count: unreadCount, error: unreadError } = await client
    .from(TABLE)
    .select('id', { count: 'exact', head: true })
    .is('read_at', null);
  if (unreadError) return { data: null, error: asError(unreadError) };
  return {
    data: {
      items,
      unreadCount: unreadCount ?? 0,
      nextCursor: hasMore ? items[items.length - 1]?.created_at ?? null : null,
    },
    error: null,
  };
}

/** Mark one notification read; the database RLS policy must enforce ownership. */
export async function markNotificationRead(
  client: SupabaseClient,
  notificationId: string,
): Promise<NotificationResult<boolean>> {
  if (!notificationId.trim()) return { data: null, error: new Error('A notification ID is required.') };
  const { data: auth, error: authError } = await client.auth.getUser();
  if (authError || !auth.user) return { data: null, error: asError(authError ?? 'Sign in required.') };

  const { data, error } = await client
    .from(TABLE)
    .update({ read_at: new Date().toISOString() })
    .eq('id', notificationId)
    .is('read_at', null)
    .select('id')
    .maybeSingle();
  if (error) return { data: null, error: asError(error) };
  return { data: Boolean(data), error: null };
}

/** Mark all currently unread notifications read for the authenticated user. */
export async function markAllNotificationsRead(
  client: SupabaseClient,
): Promise<NotificationResult<number>> {
  const { data: auth, error: authError } = await client.auth.getUser();
  if (authError || !auth.user) return { data: null, error: asError(authError ?? 'Sign in required.') };

  const { data, error } = await client
    .from(TABLE)
    .update({ read_at: new Date().toISOString() })
    .is('read_at', null)
    .select('id');
  if (error) return { data: null, error: asError(error) };
  return { data: data?.length ?? 0, error: null };
}

/** Subscribe only to the signed-in user's notification inserts. */
export async function subscribeToNotifications(
  client: SupabaseClient,
  onInsert: (notification: LiLiNotification) => void,
  onError?: (error: Error) => void,
) {
  const { data: auth, error } = await client.auth.getUser();
  if (error || !auth.user) {
    onError?.(asError(error ?? 'Sign in required.'));
    return () => undefined;
  }

  const channel = client
    .channel(`lili-notifications:${auth.user.id}`)
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: TABLE, filter: `recipient_id=eq.${auth.user.id}` },
      (payload) => onInsert(payload.new as LiLiNotification),
    )
    .subscribe((status, subscribeError) => {
      if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
        onError?.(asError(subscribeError ?? status));
      }
    });

  return () => { void client.removeChannel(channel); };
}

export function isNotificationModule(value: string): value is NotificationModule {
  return [
    'liliid', 'lilimeet', 'lilimail', 'lilistore', 'lilimaps',
    'lilibuzz', 'liliwatch', 'liliglow', 'liliads', 'games',
  ].includes(value);
}
