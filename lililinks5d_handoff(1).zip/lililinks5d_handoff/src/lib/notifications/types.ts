export type NotificationModule =
  | 'liliid' | 'lilimeet' | 'lilimail' | 'lilistore' | 'lilimaps'
  | 'lilibuzz' | 'liliwatch' | 'liliglow' | 'liliads' | 'games';

export interface LiLiNotification {
  id: string;
  recipient_id: string;
  actor_id: string | null;
  module: NotificationModule;
  event_type: string;
  title: string;
  body: string | null;
  href: string | null;
  read_at: string | null;
  created_at: string;
}

export interface NotificationPage {
  items: LiLiNotification[];
  unreadCount: number;
  nextCursor: string | null;
}

export interface NotificationResult<T> {
  data: T | null;
  error: Error | null;
}
