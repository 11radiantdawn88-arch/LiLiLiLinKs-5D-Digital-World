# LiLiNotify security and integration notes

## Client responsibilities

- Obtain the current identity from `supabase.auth.getUser()`; never accept a recipient/user ID from a UI form.
- Use `listNotifications`, `markNotificationRead`, `markAllNotificationsRead`, and `subscribeToNotifications` from `src/lib/notifications/service.ts`.
- Treat notification text and `href` as untrusted content. Render text as text, validate internal paths against an allowlist, and do not render arbitrary HTML.
- Do not place service-role keys or provider credentials in browser code.

## Database requirements

The `lili_notifications` table must have RLS enabled. SELECT and UPDATE policies must scope rows to `recipient_id = auth.uid()`. UPDATE must not permit changing `recipient_id`, `actor_id`, `module`, `event_type`, `title`, `body`, or `href`; preferably expose a narrowly scoped `mark_lili_notification_read(notification_id uuid)` RPC instead of broad UPDATE access.

Do not grant authenticated clients unrestricted INSERT. Notification creation should occur in trusted server-side code after validating the triggering event, or through narrowly scoped database functions that derive the actor from `auth.uid()` and validate the recipient's relationship to the event. The service-role key must remain server-side.

## Realtime requirements

Enable Supabase Realtime for `lili_notifications` only after confirming RLS is enabled and tested. Realtime publication membership is not a substitute for row-level security. Test with two authenticated users and an anonymous session: each user must see only their own notifications, and an anonymous client must see none.

## Pagination note

The current helper uses a timestamp cursor. If multiple notifications can share the same timestamp at the page boundary, replace this with a stable compound cursor `(created_at, id)` and matching query predicate before high-volume production use.
