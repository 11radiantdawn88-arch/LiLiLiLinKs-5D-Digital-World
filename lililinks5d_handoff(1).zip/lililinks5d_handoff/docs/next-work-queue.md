# LiLiLinKs 5D next work queue

1. Integrate LiLiNotify service into the existing authenticated app shell and add an unread badge.
2. Apply and test the shared Supabase migration in a non-production environment; verify two-user RLS isolation before production.
3. Complete LiLiMeet room RPCs, active-membership signaling policies, expiring ICE/offer records, and TURN configuration.
4. Connect the ten-module registry to the existing dashboard with explicit planned/preview/working states.
5. Implement LiLiMaps provider configuration and consent-based location handling.
6. Build LiLiBuzz feed and moderation foundations.
7. Add LiLiWatch upload/storage policies, transcoding workflow, creator channels, and moderation.
8. Build LiLiGlow safe browsing/search shell.
9. Configure LiLiAds consent, placements, reporting, and separately authorized Google Ads linking.
10. Complete platform-wide accessibility, privacy, security, Android, and deployment QA.

No module should be labeled live until its real backend, permissions, integrations, and end-to-end tests are complete.
