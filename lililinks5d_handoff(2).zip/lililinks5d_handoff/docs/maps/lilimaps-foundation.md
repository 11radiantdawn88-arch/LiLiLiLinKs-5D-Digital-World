# LiLiMaps 5D — provider-neutral foundation

## Implemented in this increment

- Coordinate, bounds, place, route, geocoding, and routing contracts.
- An explicit-consent geolocation helper with permission/error states, bounded coordinates, and no background tracking.
- HTTPS-only map-style configuration validation and required attribution.
- Provider credentials are not hard-coded; use server-side secrets for providers that require private keys.

## Intended experience

LiLiMaps is the immersive 5D map experience: contextual place discovery, navigation, layered points of interest, accessibility-aware routes, and user-controlled location context. The provider-neutral contracts keep the product independent of a single map vendor.

## Not yet implemented or verified

- No map renderer or map tiles are bundled in this foundation.
- No geocoder, directions provider, traffic feed, or offline map cache is connected.
- No location is stored or tracked by these helpers.
- No route guidance or turn-by-turn navigation is live.

## Integration requirements

1. Select a map provider and review its attribution, caching, tile-use, and commercial-use terms.
2. Configure `VITE_LILIMAPS_STYLE_URL` and `VITE_LILIMAPS_ATTRIBUTION` for the chosen style. Do not place private API secrets in `VITE_` variables; those are exposed to the browser.
3. Show a plain-language purpose prompt before calling `getCurrentLocation` and offer a manual-location fallback.
4. Request location only while the relevant map/navigation feature is active. Stop watches and clear precise coordinates when consent is revoked or the feature closes.
5. Add provider-specific geocoding and routing adapters, rate limits, error handling, and tests before describing those capabilities as available.

## Privacy acceptance checks

- No geolocation call occurs when `consent.granted` is false.
- Denial and unsupported-device states do not block manual map use.
- Coordinates are validated before use.
- Location is not written to analytics, notifications, or profiles by this module.
- Provider style URLs must be HTTPS and carry attribution.
