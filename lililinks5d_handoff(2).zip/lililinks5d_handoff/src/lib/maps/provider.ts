import type { MapProviderConfig } from './types';

/** Validate configuration before passing a provider style to a map renderer. */
export function validateMapProviderConfig(value: MapProviderConfig): MapProviderConfig {
  let parsed: URL;
  try {
    parsed = new URL(value.styleUrl);
  } catch {
    throw new Error('LiLiMaps requires a valid map style URL.');
  }
  if (parsed.protocol !== 'https:') throw new Error('Map style URLs must use HTTPS.');
  if (!value.attribution.trim()) throw new Error('Map provider attribution is required.');
  return { styleUrl: parsed.toString(), attribution: value.attribution.trim() };
}

/**
 * Keep provider credentials in server-side configuration where possible.
 * Never commit a real provider token into this source file or client bundle.
 */
export function getMapProviderConfig(env: Record<string, string | undefined>): MapProviderConfig | null {
  const styleUrl = env.VITE_LILIMAPS_STYLE_URL;
  const attribution = env.VITE_LILIMAPS_ATTRIBUTION;
  if (!styleUrl || !attribution) return null;
  return validateMapProviderConfig({ styleUrl, attribution });
}
