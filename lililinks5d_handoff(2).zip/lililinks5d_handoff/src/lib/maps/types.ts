/** Provider-neutral contracts for the LiLiMaps immersive 5D map experience. */
export interface MapCoordinate {
  latitude: number;
  longitude: number;
}

export interface MapBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

export interface MapPlace {
  id: string;
  name: string;
  coordinate: MapCoordinate;
  category?: string;
  address?: string;
}

export interface MapRouteStep {
  instruction: string;
  distanceMeters: number;
  durationSeconds: number;
}

export interface MapRoute {
  geometry: readonly MapCoordinate[];
  distanceMeters: number;
  durationSeconds: number;
  steps: readonly MapRouteStep[];
}

export interface GeocodingProvider {
  search(query: string, options?: { limit?: number; signal?: AbortSignal }): Promise<readonly MapPlace[]>;
}

export interface RoutingProvider {
  route(from: MapCoordinate, to: MapCoordinate, options?: { signal?: AbortSignal }): Promise<MapRoute>;
}

export type LocationPermissionState = 'unknown' | 'granted' | 'denied' | 'unsupported';
export interface LocationConsent {
  /** Must be true only after a clear, user-initiated opt-in. */
  granted: boolean;
  purpose: 'map-centering' | 'navigation';
}

export interface MapProviderConfig {
  /** HTTPS style URL from a provider the project is authorized to use. */
  styleUrl: string;
  attribution: string;
}
