import type { LocationConsent, LocationPermissionState, MapCoordinate } from './types';

export interface LocationResult {
  coordinate: MapCoordinate | null;
  permission: LocationPermissionState;
  error: Error | null;
}

const validCoordinate = (value: MapCoordinate): boolean =>
  Number.isFinite(value.latitude) && Number.isFinite(value.longitude) &&
  value.latitude >= -90 && value.latitude <= 90 &&
  value.longitude >= -180 && value.longitude <= 180;

/**
 * Read the device's location only after an explicit in-app consent decision.
 * Browser permission prompts are not a substitute for explaining the purpose.
 */
export async function getCurrentLocation(
  consent: LocationConsent,
  options: PositionOptions = { enableHighAccuracy: false, maximumAge: 15_000, timeout: 12_000 },
): Promise<LocationResult> {
  if (!consent.granted) {
    return { coordinate: null, permission: 'unknown', error: new Error('Location access has not been enabled.') };
  }
  if (typeof navigator === 'undefined' || !navigator.geolocation) {
    return { coordinate: null, permission: 'unsupported', error: new Error('This device does not support browser location.') };
  }

  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        const coordinate = { latitude: coords.latitude, longitude: coords.longitude };
        if (!validCoordinate(coordinate)) {
          resolve({ coordinate: null, permission: 'unknown', error: new Error('The device returned an invalid location.') });
          return;
        }
        resolve({ coordinate, permission: 'granted', error: null });
      },
      (cause) => {
        const permission = cause.code === cause.PERMISSION_DENIED ? 'denied' : 'unknown';
        resolve({ coordinate: null, permission, error: new Error(cause.message || 'Unable to read device location.') });
      },
      options,
    );
  });
}

/** Remove precise coordinates from app state when the user revokes consent. */
export function clearLocationOnRevocation(consent: LocationConsent): MapCoordinate | null {
  return consent.granted ? null : null;
}

export function isValidMapCoordinate(value: MapCoordinate): boolean {
  return validCoordinate(value);
}
