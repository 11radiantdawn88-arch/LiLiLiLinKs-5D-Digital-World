# LiLiLinKs 5D — connected platform architecture

## Shared platform services
- LiLiID: canonical authenticated identity, profile, handle, avatar, preferences and consent.
- Notification center: in-app notifications with per-category preferences; email/push are separate delivery channels requiring setup.
- Media service: upload metadata, storage policies, transcoding jobs, thumbnails and moderation state.
- Search: module-aware search over public content only; private mail and private profiles are excluded unless explicitly authorized.
- Moderation: report, block, mute, review queue, audit trail and appeals.
- Billing: server-verified provider webhooks; never trust browser payment-success callbacks.
- Analytics: aggregate, privacy-conscious events; consent and retention policy required.

## Module boundaries
- LiLiMaps: places, saved places, map layers, routes, events and business listings. Location access is optional and foreground-only by default.
- LiLiBuzz: posts, comments, reactions, follows, communities, direct-message entry points and notification events.
- LiLiWatch: creator channels, videos, playlists, subscriptions, live sessions, comments, moderation and creator analytics.
- LiLiGlow: search and safe browsing experience; external sites open in a controlled browser context where available. It must not bypass site security or browser restrictions.
- LiLiMail: internal mailbox messaging and external email delivery are distinct capabilities. `@lilimail.com` addresses must not be represented as deliverable until the domain is owned, verified and mail infrastructure is configured.
- LiLiAds: consent-aware ad placements, campaign inventory, impressions/click reporting and fraud controls. Google Ads account linking is an owner-authorized integration, not a hardcoded key.
- LiLiGames: casual games and multiplayer first. Any real-money casino, wagering, fish-table/keno/poker cash play or payouts require jurisdiction-specific legal, age, identity, AML, geolocation, licensing and payment-provider approval before implementation.

## Cross-cutting nonfunctional requirements
- Mobile-first responsive UI, keyboard accessibility and screen-reader labels.
- Server-side authorization and row-level security for every private record.
- Rate limits, abuse reporting, spam prevention and audit logs.
- Data export/deletion workflows and privacy policy before public launch.
- Unit tests, database policy tests, route tests and two-device end-to-end tests.
- Feature status labels must distinguish working, preview, concept and owner-setup states.
