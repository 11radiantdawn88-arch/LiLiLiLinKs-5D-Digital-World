# Module completion matrix and acceptance gates

| Module | First usable milestone | Required acceptance evidence | External dependency |
|---|---|---|---|
| LiLiID | Shared profile/identity and permissions across modules | One account can access all authorized modules; RLS tests pass | Existing Supabase auth |
| LiLiMeet | Two-device WebRTC calls | Two Android devices exchange live audio/video, switch cameras, recover after interruption | Signaling + TURN; optional projector SDK |
| LiLiMaps | Map, search, current-location opt-in, route display | Search result, map pan/zoom, permission denial, route fallback tested | Map tiles/geocoder/router |
| LiLiBuzz | Authenticated feed, posts, reactions, comments, follows | CRUD, pagination, abuse/report/block and RLS tests | Supabase storage for media |
| LiLiWatch | Creator channels, uploads, playlists, comments, live placeholder | Upload limits, playback, moderation and creator ownership tests | Video storage/transcoding/live provider |
| LiLiGlow | Search interface and safe external navigation | Search results labeled, safe URL handling, no claim of unrestricted browsing | Search API if selected |
| LiLiMail | Internal inbox and message delivery | Authenticated send/receive, unread state, notification preferences | Verified mail domain/provider for external email |
| LiLiAds | Ad placements and campaign dashboard | Consent, frequency caps, click/impression validation, fraud controls | Google Ads account only if owner links it |
| LiLiGames | Casual games and multiplayer | Matchmaking, anti-cheat basics, age-appropriate moderation | Realtime backend; real-money gaming separately gated by law/licensing |
| LiLiStore | Existing catalog/cart plus real checkout | Webhook-verified test payment, idempotency, refunds, order history | Owner's verified Stripe account |

A module is not complete merely because its screen exists. Completion requires functional behavior, server-side authorization, tests, and any necessary owner/provider configuration.
