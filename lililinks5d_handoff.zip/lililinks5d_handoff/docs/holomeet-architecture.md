# HoloMeet 5D — engineering specification

## User experience
- Caller creates a private room and shares a short-lived invite link/code.
- Invitee joins after authentication and explicit camera/microphone permission.
- Both devices send camera and microphone streams simultaneously.
- Front/rear camera switching is available on supported Android browsers.
- Each participant sees the other in a full-screen stage with optional self-view.
- Connection state, microphone/camera state, network quality and reconnection are visible.
- Optional spatial scene positions the remote participant; the fallback is ordinary full-screen video.
- Projection mode is an output target for compatible external hardware, never a claim that a phone camera projects light.

## Media architecture
- WebRTC peer connection for media.
- Authenticated signaling channel for offer/answer/ICE exchange.
- STUN for discovery; TURN relay is required for dependable connectivity on restrictive mobile networks.
- Adaptive simulcast / resolution constraints based on device and bandwidth.
- Do not record by default. If recording is added, require explicit consent from all participants and retention controls.

## Security requirements
- Only authenticated room members may subscribe to room signaling.
- Invite codes are random, short-lived, single-use or explicitly revocable; store only a hash.
- RLS on room and participant records; no client-side service-role keys.
- Never trust room IDs or participant IDs supplied by the browser without server authorization.
- Camera/microphone access only after a direct user action and browser permission.
- End call closes tracks, peer connections, channels and object URLs.

## Hardware and display modes
1. Phone-only: full-screen remote video; works on normal Android phones.
2. External screen/projector: supported browser/device casting or vendor SDK; validate latency and aspect ratio.
3. Depth/spatial display: only when the target display supports the needed depth/light-field format.
4. True life-size volumetric presence: later hardware-dependent research; do not advertise as working until tested on named hardware.

## Acceptance tests
- Two separate authenticated Android devices can join the same room.
- Both can see and hear each other in both directions.
- Camera switching works or shows a clear unsupported-device message.
- Denied permissions do not crash the page.
- Reconnection recovers after a brief network interruption.
- Leaving a room stops all local media tracks and closes signaling.
- An unauthenticated or non-member cannot read or inject signaling.
- No camera, microphone, recording, or projection is claimed active when it is not.
