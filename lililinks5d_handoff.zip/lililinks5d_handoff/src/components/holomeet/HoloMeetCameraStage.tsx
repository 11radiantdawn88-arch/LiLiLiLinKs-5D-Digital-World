import { useCallback, useEffect, useRef, useState } from "react";
import { Camera, CameraOff, Mic, MicOff, RefreshCw, Video } from "lucide-react";

type FacingMode = "user" | "environment";
type CameraState = "idle" | "requesting" | "ready" | "denied" | "unsupported" | "error";

/**
 * Local camera/microphone diagnostic stage for HoloMeet.
 * This intentionally does NOT pretend to be a remote call: peer signaling and
 * TURN configuration are separate integration steps documented in docs/holomeet-architecture.md.
 */
export function HoloMeetCameraStage() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facing, setFacing] = useState<FacingMode>("user");
  const [cameraState, setCameraState] = useState<CameraState>("idle");
  const [error, setError] = useState<string>("");
  const [muted, setMuted] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);

  const stopTracks = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  const startCamera = useCallback(async (nextFacing = facing) => {
    stopTracks();
    setError("");
    setCameraState("requesting");
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraState("unsupported");
      setError("This browser does not provide camera access. Open LiLiLinKs in a supported, up-to-date Android browser over HTTPS.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: { facingMode: { ideal: nextFacing }, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } },
      });
      streamRef.current = stream;
      stream.getAudioTracks().forEach((track) => { track.enabled = !muted; });
      stream.getVideoTracks().forEach((track) => { track.enabled = cameraOn; });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => undefined);
      }
      setFacing(nextFacing);
      setCameraState("ready");
    } catch (cause) {
      const err = cause instanceof Error ? cause : new Error("Camera setup failed");
      setCameraState(err.name === "NotAllowedError" || err.name === "PermissionDeniedError" ? "denied" : "error");
      setError(err.name === "NotFoundError" ? "No compatible camera or microphone was found." : err.name === "NotAllowedError" ? "Camera or microphone permission was denied. Allow access in your browser settings and try again." : err.message);
    }
  }, [cameraOn, facing, muted, stopTracks]);

  useEffect(() => () => stopTracks(), [stopTracks]);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    streamRef.current?.getAudioTracks().forEach((track) => { track.enabled = !next; });
  };
  const toggleCamera = () => {
    const next = !cameraOn;
    setCameraOn(next);
    streamRef.current?.getVideoTracks().forEach((track) => { track.enabled = next; });
  };

  return (
    <section className="w-full max-w-3xl overflow-hidden rounded-3xl border border-border bg-card">
      <div className="relative aspect-video bg-black">
        <video ref={videoRef} autoPlay muted playsInline className="h-full w-full object-cover" aria-label="Your local camera preview" />
        {cameraState !== "ready" && (
          <div className="absolute inset-0 grid place-items-center p-6 text-center text-white">
            <div>
              <Video className="mx-auto mb-3 size-10 opacity-70" />
              <p className="font-semibold">HoloMeet camera check</p>
              <p className="mt-2 max-w-md text-sm text-white/70">Start your camera to check device permissions and framing. This is a local preview, not a connected call.</p>
              {error && <p role="alert" className="mt-3 text-sm text-amber-200">{error}</p>}
            </div>
          </div>
        )}
        {cameraState === "ready" && <span className="absolute left-3 top-3 rounded-full bg-black/60 px-3 py-1 text-xs text-white">Local preview · not in a call</span>}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={toggleMute} disabled={cameraState !== "ready"} className="inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm disabled:opacity-40" aria-pressed={muted}>
            {muted ? <MicOff className="size-4" /> : <Mic className="size-4" />}{muted ? "Unmute" : "Mute"}
          </button>
          <button type="button" onClick={toggleCamera} disabled={cameraState !== "ready"} className="inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm disabled:opacity-40" aria-pressed={!cameraOn}>
            {cameraOn ? <Camera className="size-4" /> : <CameraOff className="size-4" />}{cameraOn ? "Camera off" : "Camera on"}
          </button>
          <button type="button" onClick={() => void startCamera(facing === "user" ? "environment" : "user")} disabled={cameraState !== "ready"} className="inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm disabled:opacity-40">
            <RefreshCw className="size-4" />Switch camera
          </button>
        </div>
        <button type="button" onClick={() => void startCamera()} disabled={cameraState === "requesting"} className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50">
          {cameraState === "requesting" ? "Requesting…" : cameraState === "ready" ? "Restart camera" : "Start camera"}
        </button>
      </div>
      <p className="px-4 pb-4 text-xs text-muted-foreground">Device check only. No video is uploaded or transmitted. A real two-person call requires authenticated signaling, WebRTC peer setup and TURN relay configuration.</p>
    </section>
  );
}
