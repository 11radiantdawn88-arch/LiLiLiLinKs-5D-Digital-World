LiLiLinKs 5D Digital World — Netlify static deployment package

Contents:
- index.html: existing single-page LiLiLinKs 5D browser prototype
- _headers: baseline browser security headers for Netlify static hosting

Manual Netlify deploy:
1. Sign in to Netlify.
2. Open https://app.netlify.com/drop (or use Add new site > Deploy manually).
3. Upload/extract this ZIP and drag the lililinks-netlify-deploy folder's contents
   into the drop area (Netlify accepts a folder of static site files).
4. Wait for Netlify to report a successful deploy, then open the generated site URL.

Important:
This publishes only the static browser prototype. It does not enable LiLiID accounts,
backend/database, real email delivery, live meetings, multiplayer gaming, checkout,
payments, or affiliate tracking. Those require separate implementation and services.
Do not upload credentials or secret keys into this static package.
