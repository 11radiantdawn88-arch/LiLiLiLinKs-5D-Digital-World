-- LiLiLinKs 5D shared foundation. Review and test on a staging project before applying.
-- Client access is deliberately narrow: room/member mutations go through RPCs;
-- notifications are created by trusted server-side code only.
create extension if not exists pgcrypto;

create table if not exists public.lili_meeting_rooms (
 id uuid primary key default gen_random_uuid(),
 created_by uuid not null references auth.users(id) on delete cascade,
 title text not null default 'LiLiMeet room' check (char_length(title) between 1 and 120),
 room_state text not null default 'open' check (room_state in ('open','closed')),
 created_at timestamptz not null default now(), closed_at timestamptz,
 constraint lili_room_closed_consistency check ((room_state='open' and closed_at is null) or (room_state='closed' and closed_at is not null))
);
create table if not exists public.lili_meeting_members (
 room_id uuid not null references public.lili_meeting_rooms(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 joined_at timestamptz not null default now(), left_at timestamptz,
 primary key (room_id,user_id)
);
create table if not exists public.lili_meeting_signals (
 id uuid primary key default gen_random_uuid(),
 room_id uuid not null references public.lili_meeting_rooms(id) on delete cascade,
 sender_id uuid not null references auth.users(id) on delete cascade,
 recipient_id uuid not null references auth.users(id) on delete cascade,
 signal_type text not null check (signal_type in ('offer','answer','ice-candidate','hangup')),
 payload jsonb,
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default (now() + interval '10 minutes'),
 constraint lili_signal_not_self check (sender_id <> recipient_id),
 constraint lili_signal_payload_size check (pg_column_size(payload) <= 65536),
 constraint lili_signal_expiry check (expires_at > created_at and expires_at <= created_at + interval '15 minutes')
);
create table if not exists public.lili_notifications (
 id uuid primary key default gen_random_uuid(),
 recipient_id uuid not null references auth.users(id) on delete cascade,
 actor_id uuid references auth.users(id) on delete set null,
 module text not null check (module in ('platform','liliid','lilimail','lilimeet','lilimaps','lilibuzz','liliwatch','liliglow','liliads','liligames','lilistore')),
 event_type text not null check (char_length(event_type) between 1 and 80),
 title text not null check (char_length(title) between 1 and 160),
 body text not null default '' check (char_length(body) <= 2000),
 target_path text, read_at timestamptz, created_at timestamptz not null default now()
);

create index if not exists lili_rooms_creator_idx on public.lili_meeting_rooms(created_by,created_at desc);
create index if not exists lili_members_user_idx on public.lili_meeting_members(user_id,joined_at desc);
create index if not exists lili_signals_recipient_idx on public.lili_meeting_signals(recipient_id,created_at desc);
create index if not exists lili_signals_expiry_idx on public.lili_meeting_signals(expires_at);
create index if not exists lili_notifications_recipient_idx on public.lili_notifications(recipient_id,created_at desc);
create index if not exists lili_notifications_unread_idx on public.lili_notifications(recipient_id,created_at desc) where read_at is null;

-- SECURITY DEFINER helpers avoid recursive RLS checks between rooms and members.
create or replace function public.lili_is_active_room_member(p_room_id uuid, p_user_id uuid)
returns boolean language sql stable security definer set search_path = pg_catalog, public
as $$ select exists (select 1 from public.lili_meeting_members m where m.room_id=p_room_id and m.user_id=p_user_id and m.left_at is null) $$;
revoke all on function public.lili_is_active_room_member(uuid,uuid) from public, anon;
grant execute on function public.lili_is_active_room_member(uuid,uuid) to authenticated;

create or replace function public.lili_create_meeting_room(p_title text default 'LiLiMeet room')
returns uuid language plpgsql security definer set search_path = pg_catalog, public, auth
as $$
declare v_uid uuid := auth.uid(); v_room uuid;
begin
 if v_uid is null then raise exception 'Authentication required'; end if;
 if p_title is null or char_length(btrim(p_title)) not between 1 and 120 then raise exception 'Room title must be 1–120 characters'; end if;
 insert into public.lili_meeting_rooms(created_by,title) values(v_uid,btrim(p_title)) returning id into v_room;
 insert into public.lili_meeting_members(room_id,user_id) values(v_room,v_uid);
 return v_room;
end $$;

create or replace function public.lili_join_open_meeting(p_room_id uuid)
returns void language plpgsql security definer set search_path = pg_catalog, public, auth
as $$
declare v_uid uuid := auth.uid();
begin
 if v_uid is null then raise exception 'Authentication required'; end if;
 perform 1 from public.lili_meeting_rooms r where r.id=p_room_id and r.room_state='open' for update;
 if not found then raise exception 'Open room not found'; end if;
 insert into public.lili_meeting_members(room_id,user_id) values(p_room_id,v_uid)
 on conflict(room_id,user_id) do update set joined_at=now(),left_at=null;
end $$;

create or replace function public.lili_leave_meeting(p_room_id uuid)
returns void language plpgsql security definer set search_path = pg_catalog, public, auth
as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 update public.lili_meeting_members set left_at=now()
 where room_id=p_room_id and user_id=auth.uid() and left_at is null;
end $$;

create or replace function public.lili_close_meeting(p_room_id uuid)
returns void language plpgsql security definer set search_path = pg_catalog, public, auth
as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 update public.lili_meeting_rooms set room_state='closed',closed_at=now()
 where id=p_room_id and created_by=auth.uid() and room_state='open';
 if not found then raise exception 'Room not found or not owned by caller'; end if;
end $$;

revoke all on function public.lili_create_meeting_room(text),public.lili_join_open_meeting(uuid),public.lili_leave_meeting(uuid),public.lili_close_meeting(uuid) from public,anon;
grant execute on function public.lili_create_meeting_room(text),public.lili_join_open_meeting(uuid),public.lili_leave_meeting(uuid),public.lili_close_meeting(uuid) to authenticated;

alter table public.lili_meeting_rooms enable row level security;
alter table public.lili_meeting_members enable row level security;
alter table public.lili_meeting_signals enable row level security;
alter table public.lili_notifications enable row level security;

drop policy if exists "room creator or active member reads room" on public.lili_meeting_rooms;
create policy "room creator or active member reads room" on public.lili_meeting_rooms for select to authenticated
using (created_by=auth.uid() or public.lili_is_active_room_member(id,auth.uid()));
drop policy if exists "authenticated users create own room" on public.lili_meeting_rooms;
drop policy if exists "creator updates room" on public.lili_meeting_rooms;

 drop policy if exists "members read membership" on public.lili_meeting_members;
create policy "members read membership" on public.lili_meeting_members for select to authenticated
using (user_id=auth.uid() or exists(select 1 from public.lili_meeting_rooms r where r.id=room_id and r.created_by=auth.uid()));
drop policy if exists "join open room as self" on public.lili_meeting_members;
drop policy if exists "leave own membership" on public.lili_meeting_members;

 drop policy if exists "participants read addressed signals" on public.lili_meeting_signals;
create policy "active participants read unexpired addressed signals" on public.lili_meeting_signals for select to authenticated
using (expires_at>now() and (sender_id=auth.uid() or recipient_id=auth.uid()) and public.lili_is_active_room_member(room_id,auth.uid()));
drop policy if exists "active room members send signals" on public.lili_meeting_signals;
create policy "active room members send addressed signals" on public.lili_meeting_signals for insert to authenticated
with check (sender_id=auth.uid() and expires_at>now() and expires_at<=now()+interval '15 minutes'
 and public.lili_is_active_room_member(room_id,sender_id)
 and public.lili_is_active_room_member(room_id,recipient_id));
drop policy if exists "sender deletes own signal" on public.lili_meeting_signals;
create policy "sender deletes own signal" on public.lili_meeting_signals for delete to authenticated using(sender_id=auth.uid());

 drop policy if exists "recipient reads notifications" on public.lili_notifications;
create policy "recipient reads notifications" on public.lili_notifications for select to authenticated using(recipient_id=auth.uid());
drop policy if exists "authenticated actor creates notification" on public.lili_notifications;
create policy "recipient marks own notification read" on public.lili_notifications for update to authenticated
using(recipient_id=auth.uid()) with check(recipient_id=auth.uid());
create policy "recipient deletes own notification" on public.lili_notifications for delete to authenticated using(recipient_id=auth.uid());

revoke all on public.lili_meeting_rooms,public.lili_meeting_members,public.lili_meeting_signals,public.lili_notifications from anon,authenticated;
grant select on public.lili_meeting_rooms,public.lili_meeting_members,public.lili_meeting_signals,public.lili_notifications to authenticated;
grant insert,delete on public.lili_meeting_signals to authenticated;
grant update(read_at) on public.lili_notifications to authenticated;
-- Trusted Edge Functions/service-role code creates notification rows. Never expose service_role to clients.

-- Supabase Realtime must include lili_meeting_signals in the publication for live delivery.
-- Schedule a server-side cleanup job: DELETE FROM public.lili_meeting_signals WHERE expires_at < now();
