# Shared foundation security review

The migration adds private meeting rooms, room membership, addressed WebRTC signaling and in-app notifications. It is a handoff asset only: it has **not** been applied to Lovable Cloud.

## Release blockers and caveats
- Review migration against the actual database before applying; test RLS with two users and an anonymous session.
- The join policy currently permits any authenticated user to join an open room. Invite-only rooms need server-validated, expiring, single-use invitation tokens and a trusted join function.
- The signal select policy currently permits sender/recipient visibility; additionally enforce room membership and expiry in production query paths. Purge expired rows on a scheduled server job.
- Client-side notification creation is not a trusted event source. Production notification fan-out must run server-side after validating the event, with actor identity derived from auth context.
- Never store TURN credentials, access tokens or private keys in signal payloads.
- WebRTC needs HTTPS, explicit camera/microphone permission, STUN and usually TURN. Signaling success does not guarantee media connectivity.
- Recording is excluded; add explicit consent, retention, deletion and legal review before implementing it.

## Acceptance tests
1. Anonymous users cannot read or write any of these tables.
2. A cannot read B's notifications or signal payloads addressed to B.
3. A cannot impersonate B as signal sender.
4. A cannot signal a user who is not an active member of the same room.
5. Closed rooms reject new membership.
6. Users cannot update another user's membership or notification rows.
7. Expired signals are not delivered and are removed by scheduled cleanup.

## Hardened migration revision
The migration now removes direct client room/member writes and exposes authenticated RPCs for create, open-room join, leave and owner close. Membership checks use a narrowly granted `SECURITY DEFINER` helper to avoid recursive RLS. Signal reads require active room membership and an unexpired addressed signal; clients cannot insert notifications. Notification creation is reserved for trusted server-side code, and clients can update only `read_at`.

Before production use, add invite-only token flows (the current join RPC intentionally joins open rooms), verify the function owner and grants in the target Supabase project, enable Realtime publication for `lili_meeting_signals`, configure scheduled expiry cleanup, and run two-user/anonymous RLS tests. The client signaling adapter does not itself provide TURN, media encryption policy beyond WebRTC defaults, abuse controls, or production reliability guarantees.
