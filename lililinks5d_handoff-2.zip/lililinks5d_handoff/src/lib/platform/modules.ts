/** Shared registry for the complete LiLiLinKs 5D module family. */
export type ModuleId = "liliid" | "lilistore" | "lilimail" | "lilimeet" | "lilimaps" | "lilibuzz" | "liliwatch" | "liliglow" | "liliads" | "liligames";
export type CapabilityState = "working" | "preview" | "planned" | "owner-setup";
export interface ModuleDefinition { id: ModuleId; name: string; path: `/${string}`; tagline: string; state: CapabilityState; dependency?: string; }
export const LILI_MODULES: readonly ModuleDefinition[] = [
 {id:"liliid",name:"LiLiID",path:"/liliid",tagline:"One identity across the 5D world",state:"working"},
 {id:"lilistore",name:"LiLiStore",path:"/lilistore",tagline:"Commerce and creator marketplace",state:"preview",dependency:"Verified payment provider before live charges"},
 {id:"lilimail",name:"LiLiMail",path:"/lilimail",tagline:"Your LiLiLinKs mailbox and messages",state:"preview",dependency:"Owned domain, DNS verification and mail provider"},
 {id:"lilimeet",name:"LiLiMeet",path:"/holomeet",tagline:"Immersive 5D meetings and two-way presence",state:"planned",dependency:"WebRTC signaling, TURN service and device testing"},
 {id:"lilimaps",name:"LiLiMaps",path:"/lilimaps",tagline:"Immersive 5D places and shared discovery",state:"planned",dependency:"Map tiles, geocoding and routing provider"},
 {id:"lilibuzz",name:"LiLiBuzz",path:"/lilibuzz",tagline:"Social world, communities and creator activity",state:"planned"},
 {id:"liliwatch",name:"LiLiWatch",path:"/liliwatch",tagline:"Video, creators, channels and live viewing",state:"planned",dependency:"Object storage, transcoding and streaming"},
 {id:"liliglow",name:"LiLiGlow",path:"/liliglow",tagline:"In-platform web discovery and browsing",state:"planned",dependency:"Search provider and safe navigation controls"},
 {id:"liliads",name:"LiLiAds",path:"/liliads",tagline:"Consent-aware creator and platform advertising",state:"planned",dependency:"Ad account authorization and privacy controls"},
 {id:"liligames",name:"LiLiGames",path:"/games",tagline:"Games, multiplayer and community play",state:"preview",dependency:"Real-money play requires licensing and provider approval"},
] as const;
export function getModule(id: ModuleId): ModuleDefinition { const found=LILI_MODULES.find(m=>m.id===id); if(!found) throw new Error(`Unknown module: ${id}`); return found; }
