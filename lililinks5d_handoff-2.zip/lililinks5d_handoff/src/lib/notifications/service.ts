import type { SupabaseClient } from "@supabase/supabase-js";
export type NotificationModule = "platform"|"liliid"|"lilimail"|"lilimeet"|"lilimaps"|"lilibuzz"|"liliwatch"|"liliglow"|"liliads"|"liligames"|"lilistore";
export interface LiLiNotification { id:string; recipient_id:string; actor_id:string|null; module:NotificationModule; event_type:string; title:string; body:string; target_path:string|null; read_at:string|null; created_at:string; }
export async function listNotifications(client:SupabaseClient,limit=30):Promise<LiLiNotification[]> {
 const {data,error}=await client.from("lili_notifications").select("id,recipient_id,actor_id,module,event_type,title,body,target_path,read_at,created_at").order("created_at",{ascending:false}).limit(Math.min(100,Math.max(1,Math.floor(limit))));
 if(error) throw error; return (data??[]) as LiLiNotification[];
}
export async function markNotificationRead(client:SupabaseClient,id:string):Promise<void> {
 const {error}=await client.from("lili_notifications").update({read_at:new Date().toISOString()}).eq("id",id).is("read_at",null); if(error) throw error;
}
export async function markAllNotificationsRead(client:SupabaseClient):Promise<void> {
 const {error}=await client.from("lili_notifications").update({read_at:new Date().toISOString()}).is("read_at",null); if(error) throw error;
}
