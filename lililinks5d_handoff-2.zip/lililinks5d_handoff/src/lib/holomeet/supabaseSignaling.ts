import type { SupabaseClient } from "@supabase/supabase-js";
import type { CallSignal, SignalingTransport } from "./types";

type DbSignal = {
  id: string; room_id: string; sender_id: string; recipient_id: string;
  signal_type: CallSignal["kind"]; payload: CallSignal["payload"];
  created_at: string; expires_at: string;
};

/** Supabase-backed signaling adapter. Enable Realtime for lili_meeting_signals.
 * Signals are retained until their short expiry so transient reconnects can recover them.
 */
export class SupabaseSignalingTransport implements SignalingTransport {
  constructor(private readonly client: SupabaseClient) {}

  async send(signal: Omit<CallSignal, "id" | "createdAt">): Promise<void> {
    const { error } = await this.client.from("lili_meeting_signals").insert({
      room_id: signal.roomId,
      sender_id: signal.senderId,
      recipient_id: signal.recipientId,
      signal_type: signal.kind,
      payload: signal.payload,
    });
    if (error) throw error;
  }

  subscribe(
    roomId: string,
    currentUserId: string,
    onSignal: (signal: CallSignal) => void,
    onError: (error: Error) => void,
  ): () => void {
    let stopped = false;
    const seen = new Set<string>();
    const deliver = (row: DbSignal) => {
      if (stopped || row.recipient_id !== currentUserId || seen.has(row.id)) return;
      if (Date.parse(row.expires_at) <= Date.now()) return;
      seen.add(row.id);
      onSignal({
        id: row.id,
        roomId: row.room_id,
        senderId: row.sender_id,
        recipientId: row.recipient_id,
        kind: row.signal_type,
        payload: row.payload,
        createdAt: row.created_at,
      });
    };

    const channel = this.client.channel(`lilimeet:${roomId}:${currentUserId}`)
      .on("postgres_changes", {
        event: "INSERT", schema: "public", table: "lili_meeting_signals",
        filter: `room_id=eq.${roomId}`,
      }, (payload) => deliver(payload.new as DbSignal))
      .subscribe((status, error) => {
        if (error) onError(error);
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
          onError(new Error(`LiLiMeet signaling subscription: ${status}`));
        }
      });

    // Recover signals sent during a brief disconnect or before subscription became active.
    void this.client.from("lili_meeting_signals")
      .select("id,room_id,sender_id,recipient_id,signal_type,payload,created_at,expires_at")
      .eq("room_id", roomId).eq("recipient_id", currentUserId)
      .gt("expires_at", new Date().toISOString()).order("created_at", { ascending: true })
      .then(({ data, error }) => {
        if (error) { if (!stopped) onError(error); return; }
        (data ?? []).forEach((row) => deliver(row as DbSignal));
      });

    return () => {
      stopped = true;
      void this.client.removeChannel(channel);
    };
  }
}

export async function createMeetingRoom(client: SupabaseClient, title: string): Promise<string> {
  const { data, error } = await client.rpc("lili_create_meeting_room", { p_title: title });
  if (error) throw error;
  if (typeof data !== "string") throw new Error("LiLiMeet room creation returned no room ID.");
  return data;
}

export async function joinOpenMeeting(client: SupabaseClient, roomId: string): Promise<void> {
  const { error } = await client.rpc("lili_join_open_meeting", { p_room_id: roomId });
  if (error) throw error;
}

export async function leaveMeeting(client: SupabaseClient, roomId: string): Promise<void> {
  const { error } = await client.rpc("lili_leave_meeting", { p_room_id: roomId });
  if (error) throw error;
}

export async function closeMeeting(client: SupabaseClient, roomId: string): Promise<void> {
  const { error } = await client.rpc("lili_close_meeting", { p_room_id: roomId });
  if (error) throw error;
}
